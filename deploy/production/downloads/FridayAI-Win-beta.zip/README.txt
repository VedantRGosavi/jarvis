FridayAI for Windows
====================

Thank you for installing FridayAI!

Getting Started:
1. Run FridayAI.exe to start the application
2. Visit https://fridayai.me/docs for documentation
3. For support, contact support@fridayai.me

Version: 1.1.0-beta
